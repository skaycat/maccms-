MacPlayer.Html = '<iframe width="100%" height="http://www.wuquk.com/vip.php?url='+MacPlayer.Height+'" src="'+MacPlayer.PlayUrl+'" frameborder="0" allowfullscreen></iframe>';
MacPlayer.Show();