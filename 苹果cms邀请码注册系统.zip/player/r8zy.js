MacPlayer.Html = '<iframe width="100%" height="'+MacPlayer.Height+'" src="'+MacPlayer.PlayUrl+'" frameborder="0" allowfullscreen></iframe>';
MacPlayer.Show();